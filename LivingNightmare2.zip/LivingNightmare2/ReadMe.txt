Welcome to Living Nightmare 2 by (Mark Chen)
----------------------------------------------

In order to install, just drag the entire folder onto wherever you want.

There are two options to choose from the uncensored version is the one I originally created with (some violent scenes)
and the censored version which is edited (poorly so there might be bugs) to be more family friendly.

The images file is important to the game and has to be located with the LivingNightmare2.html file.

Also you can open the html file with any browser and it should work.

There are some secrets in the game to look for.

There are some clues below (scroll down) if you get stuck anywhere.

But some minor secrets and the true ending will not be revealed.

Thanks for playing :)



















Secrets:
1) On the main screen (scroll down) to the bottom of the screen.
2) If you cannot get through the spider on the character select screen name yourself "Peter Parker" (exactly like how it is shown here).
3) In the monster battle there is a secret end to the fight (when you hit the monster). Look closely.

Ending:
1) The ending of the game is where the rock falls on your head. You cannot escape the loop.
2) There are two alternate endings that are possible.